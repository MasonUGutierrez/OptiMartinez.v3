create
    definer = root@localhost procedure borrar_asignacion(IN id_u int(10))
DELETE from usuario_rol where id_usuario = id_u;


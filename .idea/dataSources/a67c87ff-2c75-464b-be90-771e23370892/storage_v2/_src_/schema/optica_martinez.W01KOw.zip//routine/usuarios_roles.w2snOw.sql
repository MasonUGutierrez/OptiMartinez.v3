create
    definer = root@localhost procedure usuarios_roles(IN n_rol int(10))
select u.id_usuario,u.nombre,u.apellido
  from usuario u
 where not exists (select null from `usuario-rol` r where r.id_usuario = u.id_usuario and r.id_rol = n_rol);

